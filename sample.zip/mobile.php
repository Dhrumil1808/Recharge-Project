<h2>Recharge Mobile</h2>

<form action="submit-mobile.php" method="post">

<label>Choose Operator:</label><br/>
<select name="operator">
              <option value="AT" selected="yes">Airtel</option>
               <option value="AL">Aircel</option>
               <option value="BS">BSNL</option>
               <option value="BSS">BSNL Special/Validity</option>
               <option value="ID">Idea</option>
               <option value="VF">Vodafone</option>
               <option value="TD">Docomo GSM</option>
               <option value="TDS">Docomo Special GSM</option>
               <option value="TI">Docomo CDMA</option>
                <option value="RG">Reliance GSM</option>
               <option value="RC">Reliance CDMA</option>
	      <option value="MS">MTS</option>
              <option value="UN">Uninor</option>
               <option value="UNS">Uninor Special</option>
               <option value="LM">Loop Mobile</option>
              <option value="VD">Videocon</option>
               <option value="VDS">Videocon Special</option>
               <option value="MTD">MTNL Delhi</option>
               <option value="MTDS">MTNL Delhi Special</option>
               <option value="MTM">MTNL Mumbai</option>
                <option value="MTMS">MTNL Mumbai Special</option>
               <option value="TW">Tata Walky</option>
</select>
<br/>

<label>Enter Mobile Number:</label><br/>
<input type="text" name="servicenumber" maxlength="10"/></span>
<br/>

<label>Enter Amount:</label><br/>
<input type="text" name="amount"/></span>
<br/>
<br/>
<input type="submit" value="Recharge">

</form>