<h2>Recharge DTH</h2>

<form action="submit-dth.php" method="post">

<label>Choose Operator:</label><br/>
<select name="operator">
              <option value="AD" selected="yes">Airtel DTH</option>
               <option value="DT">Dish TV DTH</option>
               <option value="TS">Tata Sky DTH</option>
               <option value="SD">Sun DTH</option>
               <option value="VT">Videocon D2H</option>
               <option value="BT">Big TV DTH</option>
</select>
<br/>

<label>DTH Account/VCC ID:</label><br/>
<input type="text" name="servicenumber" /></span>
<br/>

<label>Enter Amount:</label><br/>
<input type="text" name="amount"/></span>
<br/>
<br/>
<input type="submit" value="Recharge">

</form>