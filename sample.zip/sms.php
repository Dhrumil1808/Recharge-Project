<h2>Send SMS</h2>

<form action="submit_sms.php" method="post">

<label>Enter 10 Digit Mobile Number:</label><br/>
<input type="text" name="mobile" maxlength="10"/></span>
<br/>

<label>Message:</label><br/>
<textarea name="msg"></textarea>
<br/>
<br/>
<input type="submit" value="Send">

</form>
