<?
//sample php code

//this will collect data from form
$operator = $_POST['operator']; 
$servicenumber = $_POST['servicenumber'];
$amount = $_POST['amount'];
//end of data collection from form


//check whether user enter some data or not
if(empty($operator)){
echo"select operator";
exit;
}
if(empty($servicenumber)){
echo"enter DTH number";
exit;
}
if(empty($amount)){
echo"enter amount";
exit;
}
//end of data input checking


//common settings
$myjoloappkey = ""; //your jolo appkey
$mode = "1"; //set 1 for live recharge, set 0 for demo recharge
$myorderid = ""; // It is your website generated unique transaction id

//doing recharge now by hitting jolo api
$ch = curl_init();
$timeout = 160; // set to zero for no timeout
$myurl = "http://www.jolo.in/api/recharge_advance.php?mode=$mode&key=$myjoloappkey&operator=$operator&service=$servicenumber&amount=$amount&orderid=$myorderid";
curl_setopt ($ch, CURLOPT_URL, $myurl);
curl_setopt ($ch, CURLOPT_HEADER, 0);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$file_contents = curl_exec($ch);
curl_close($ch);
//echo"$file_contents";

//capture the response from jolo api
//splitting each data as single
$maindata = explode(",", $file_contents);

$transactionid = $maindata[0]; //it is jolo generated transaction id
$jolostatus = $maindata[1]; //it is status of recharge SUCCESS,PENDING OR FAILED
$operator= $maindata[2]; //operator code
$service= $maindata[3]; //mobile number or dth number
$amount= $maindata[4]; //amount
$mywebsiteid= $maindata[5]; //client website order id
$errorcode= $maindata[6]; // api error code when txn fails
$operatorid= $maindata[7]; //original operator transaction id

//cases
if($jolostatus=='SUCCESS'){
//YOUR REST QUERY HERE
} 
if($jolostatus=='PENDING'){
//YOUR REST QUERY HERE
}
if($jolostatus=='FAILED'){
//YOUR REST QUERY HERE
}

//TIME OUT CASE OR EMPY REPONSE
if(empty($jolostatus)){
//YOUR REST QUERY HERE
//consider as pending
}


//display the result to customer
echo"Transaction ID: $transactionid (This is jolo orderid)";
echo"<br/>";
echo"Recharge Status: $jolostatus";
echo"<br/>";
echo"Operator: $operator";
echo"<br/>";
echo"Service Number: $service";
echo"<br/>";
echo"Amount: $amount";
echo"<br/>";
echo"Client order id: $mywebsiteid";
echo"<br/>";
echo"Operator Txn ID: $operatorid";
echo"<br/>";
echo"Error No.: $errorcode";
echo"<br/>";

?>